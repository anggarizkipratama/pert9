/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sepedamootor;

/**
 *
 * @author user
 */
public class pelajar {
      private String nama;
    private long tinggi;
    private long berat;

public pelajar (String nama, long tinggi, long berat) {
    this.nama = nama;
    this.tinggi = tinggi;
    this.berat = berat;
}
public String tampilPelajar(){
    return ("Nama\t : " + nama + "\nTinggi\t: " + tinggi + "\nBerat\t: " + berat + "\n");
}
} 
class Siswa extends pelajar {
    private String nim, asalsekolah;
    private long nilai;
    public Siswa(String nama, long tinggi, long berat, String nim, String asalsekolah, long nilai) {
        super(nama, tinggi, berat);
        this.nim = nim;
        this.asalsekolah = asalsekolah;
        this.nilai = nilai;
    }
    public String tampilSiswa() {
        return (super.tampilPelajar()+"NIM\t: " + nim + "\nAsal Sekolah\t : " + asalsekolah + "\nNilai\t : " + nilai);
    }
}

