/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sepedamootor;

/**
 *
 * @author hp
 */
public class Yamaha {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SepedaMotor motor = new SepedaMotor();
        motor.inputmerk(" yamaha ");
        System.out.println("merk motor ini adalah"+ motor.tampilmerk());
    motor.inputTipe("mx 125");
    motor.inputtangki(5);
    motor.inputHarga(20000000);
    System.out.println("rincian motor :");
    System.out.println("merk : "+motor.tampilmerk());
    System.out.println("tipe :"+motor.tampiltipe());
    System.out.println("tangki:"+motor.tampiltangki());
    System.out.println("harga:"+motor.tampilharga());
    }
    
}
