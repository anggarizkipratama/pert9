/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sepedamootor;

public class login {
  
         private String user, pass;
    login () {
        this.user = "";
        this.pass = "";
    }
    login (String user, String pass) {
        this.user = user;
        this.pass = pass;
    }
    void inputUser() {
        this.user = user;
    }
    void inputPass() {
        this.pass = pass;
    }
}


    

