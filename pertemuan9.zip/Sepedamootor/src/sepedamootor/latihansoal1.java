/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sepedamootor;

import static java.lang.Integer.parseInt;
import javax.swing.JOptionPane;
public class latihansoal1 {

    public static void main(String[] args) {
       String angka1,angka2;
       angka1 = JOptionPane.showInputDialog("masukan angka pertama");
       angka2 = JOptionPane.showInputDialog("masukan angka kedua");
    JOptionPane.showInputDialog(null,parseInt(angka1)+parseInt(angka2));
    }
    
}
