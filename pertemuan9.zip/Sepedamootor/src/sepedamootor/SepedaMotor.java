/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sepedamootor;

/**
 *
 * @author hp
 */
public class SepedaMotor {
    private String merk,tipe;
    private int tangki;
    private long harga;
    public void tampilmerk (String merk){
        this.merk = merk;
    }
    
   public void inputmerk (String merk){
        this.merk = merk;
    }
    
    public String tampilmerk(){
        return merk;
    }
public void inputTipe (String tipe){
    this.tipe = tipe;
}
public void inputtangki (int tangki){
    this.tangki= tangki;
}
public void inputHarga (long harga){
    this.harga =harga;
}
public String tampiltipe(){
    return tipe;
}
public int tampiltangki(){
    return tangki;
}
public long tampilharga(){

return harga;
}
}


