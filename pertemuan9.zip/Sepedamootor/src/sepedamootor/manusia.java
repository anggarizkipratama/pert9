/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sepedamootor;

/**
 *
 * @author user
 */
public class manusia {
     public String nama, hobby, pekerjaan;
    public manusia (String nm, String hobby, String kerja) {
        this.nama = nm;
        this.hobby = hobby;
        this.pekerjaan = kerja;
    }
    public String tampilManusia() {
        return ("Nama\t\t: " + nama + "\n" + "Hobby\t\t: " + hobby + "\n" + "Pekerjaan\t\t: " + pekerjaan + "\n");
    }
}
class programmer extends manusia {
    public programmer(String nm, String hobby, String kerja) {
        super(nm, hobby, kerja);
    }
    
}
class polisi extends manusia {
    public polisi(String nm, String hobby, String kerja) {
        super(nm, hobby, kerja);
}
}


